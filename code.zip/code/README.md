# Code for fact-to-text generation on the dataset

The code is written in pytorch-lightning and using huggingface transformers. The requirements.txt file to create the expected conda environment is attached in root directory.

Modify run_finetune.sh with appropriate hyperparameters before starting the training of model.

Implementation of role_specific_embeddings require changes in the transformers library by huggingface. You must first clone it in root directory and then replace the file modeling_t5.py with the one provided in here. Then, pip install the edited version of transformers by using `cd transformers` followed by `pip install `.

Evaluating any checkpoint needs a small change in train.py i.e of commenting model.fit() and uncommenting model.test() line. Also, make sure to pass appropriate checkpoint path in run_finetune.sh before starting evaluation.